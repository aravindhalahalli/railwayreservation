def bin(arr , l, r, x):
    if r >= l:
        mid = (l+r)//2
        if arr[mid][0] == x:
            return mid
        elif arr[mid][0] > x:
            return bin(arr, l, mid-1, x)
        else:
            return bin(arr, mid+1, r, x)
    else:
        return -1            

def delete(pn):
    f= open("index1.txt")
    t = f.read().split("\n")[:-1]
    x = list()
    print(pn)
    for i in t :
        s = i.split('|')[:-1]
        x.append(s)
    r = bin(x, 0 , len(x)-1,pn)
    print(r)
    f.seek(0 , 0)
    l = 0
    for j in range(r):
        temp = f.readline()
        l = l + len(temp)    
    f.close()
    f= open("index1.txt","r+")
    f.seek(l,0)
    d = f.readline()[:-1]
    print(d)
    f.seek(0,0)
    t = f.read().split('\n')[:-1]
    f.seek(0,0)
    for i in range(len(t)):
        if t[i] != d :    
            f.write(t[i])
            f.write('\n')
    print("nerd hallu")
    return l

